# aliases for backwards compatibility
Set-Alias -Name New-QRCodeGeolocation -Value New-PSOneQRCodeGeolocation
Set-Alias -Name New-QRCodeWifiAccess -Value New-PSOneQRCodeWifiAccess
Set-Alias -Name New-QRCodeTwitter -Value New-PSOneQRCodeTwitter
Set-Alias -Name New-QRCodeVCard -Value New-PSOneQRCodeVCard
Set-Alias -Name New-QRCodeText -Value New-PSOneQRCodeText
Set-Alias -Name New-QRCodeURI -Value New-PSOneQRCodeURI