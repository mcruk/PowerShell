# Exchange Recipient Admin Center

Manage Exchange Online Attributes stored in your local AD without Exchange Server

This web-based tool uses the new Exchange 2019 CU12 Recipient Management Tools

Guidance on how to use this is at Practical 365:

https://practical365.com/a-new-tool-to-manage-exchange-related-attributes-without-exchange-server/